# IPTV OTT Platform

Proyecto base IPTV/OTT legal con:
- Backend Node.js
- Streaming HLS
- Base de datos
- Docker listo

## 🚀 Ejecutar

docker-compose up

## 🔐 Login
user: admin
pass: 1234
