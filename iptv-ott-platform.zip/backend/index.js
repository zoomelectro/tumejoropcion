require('dotenv').config();
const express = require('express');
const jwt = require('jsonwebtoken');
const app = express();

app.use(express.json());

const users = [
  { id: 1, username: "admin", password: "1234", exp: "2026-12-01", max: 2 }
];

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username && u.password === password);

  if (!user) return res.status(401).json({ error: "Invalid" });

  const token = jwt.sign({ id: user.id }, "secret", { expiresIn: '1d' });
  res.json({ token, exp: user.exp });
});

app.get('/api/streams', (req, res) => {
  res.json([
    {
      category: "TV",
      channels: [
        { name: "Canal Demo", url: "http://localhost/hls/stream.m3u8" }
      ]
    }
  ]);
});

app.listen(3000, () => console.log("Server running"));
