CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50),
  password VARCHAR(255),
  exp_date DATE,
  max_connections INT
);

CREATE TABLE resellers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50),
  credits INT
);

CREATE TABLE streams (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  url TEXT,
  category VARCHAR(50)
);
